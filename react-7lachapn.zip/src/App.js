import React, { useState } from "react"
const formulas = [
  { id: 1, name: "Newton", category: "Physics", formula: "F = m x g" },
  { id: 2, name: "Ohm", category: "Physics", formula: "V = I x R" },
  { id: 3, name: "Circle", category: "Math", formula: "A = pi x r2" },
  { id: 4, name: "Pythagoras", category: "Math", formula: "a2 + b2 = c2" }
]
function App() {
  const [search, setSearch] = useState("")
  const [category, setCategory] = useState("All")
  const filtered = formulas.filter(f =>
    f.name.toLowerCase().includes(search.toLowerCase()) &&
    (category === "All" || f.category === category)
  )
  return (
    <div style={{ padding: "30px", maxWidth: "800px", margin: "0 auto" }}>
      <h1 style={{ textAlign: "center", color: "#2c3e50" }}>Formula Reference App</h1>
      <input placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} style={{ padding: "10px", width: "100%", marginBottom: "15px", borderRadius: "8px", border: "1px solid #ccc" }} />
      <div style={{ marginBottom: "20px" }}>
        {["All","Physics","Math"].map(cat => (
          <button key={cat} onClick={() => setCategory(cat)} style={{ marginRight: "10px", padding: "8px 16px", backgroundColor: category === cat ? "#3498db" : "#eee", color: category === cat ? "white" : "black", border: "none", borderRadius: "20px", cursor: "pointer" }}>{cat}</button>
        ))}
      </div>
      {filtered.map(f => (
        <div key={f.id} style={{ border: "1px solid #ddd", margin: "10px 0", padding: "20px", borderRadius: "10px", backgroundColor: "#f9f9f9" }}>
          <h3 style={{ color: "#2c3e50" }}>{f.name}</h3>
          <p style={{ color: "#e74c3c", fontSize: "22px", fontWeight: "bold" }}>{f.formula}</p>
        </div>
      ))}
    </div>
  )
}
export default App
